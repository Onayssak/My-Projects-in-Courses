//variaveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 24;
let raio = diametro / 2;

//velocidade da bolinha
let velocidadeXBolinha = 8;
let velocidadeYBolinha = 8;

//dimensoes das raquetes
let raqueteComprimento = 10;
let raqueteAltura = 90;

//variaveis da raquete
let xRaquete = 1;
let yRaquete = 150;

//variaveis raquete do oponente
let xRaqueteOponente = 589;
let yRaqueteOponente = 150;
let velocidadeYOponente;

//variavel colisao nas raquetes
let colidiu = false;

//placar do jogo
let meusPontos = 0;
let pontosDoOponente = 0;

//sons do jogo
let raquetada;
let marcandoPonto;
let trilhaSonora;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  verificaColisaoBorda();
  mostraRaquete(xRaquete, yRaquete);
  movimentaRaquete();
  verificaColisaoRaquete(xRaquete, yRaquete);
  //verificaColisaoRaquete();
  verificaColisaoRaquete(xRaqueteOponente, yRaqueteOponente);
  mostraRaquete(xRaqueteOponente, yRaqueteOponente);
  movimentoRaqueteOponente();
  incluiPlacar();
  marcaPonto();
}

function mostraBolinha(){
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha(){
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function verificaColisaoBorda(){
  if(xBolinha + raio > width ||
  xBolinha - raio < 0){
  velocidadeXBolinha *= -1
}
  if(yBolinha + raio> height ||
  yBolinha - raio < 0){
  velocidadeYBolinha *= -1
  }
}

function mostraRaquete(x, y){
  rect(x, y, raqueteComprimento, raqueteAltura);
}

function movimentaRaquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -= 10;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaquete += 10;
  }
}

function verificaColisaoRaquete(){
  if(xBolinha - raio < xRaquete + raqueteComprimento && yBolinha - raio < yRaquete + raqueteAltura && yBolinha + raio > yRaquete)
{
  velocidadeXBolinha *= -1;
  raquetada.play();
  }
}

function verificaColisaoRaquete(x, y){
  colidiu =
collideRectCircle(x, y, raqueteComprimento, raqueteAltura, xBolinha, yBolinha, raio);
  if (colidiu){
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}

function movimentoRaqueteOponente(){
  velocidadeYOponente = yBolinha - yRaqueteOponente - 50
  yRaqueteOponente += velocidadeYOponente * .13
}

function incluiPlacar(){
  stroke(255)
  textAlign(CENTER);
  textSize(18);
  fill(255, 69, 0);
  rect(125, 19, 50, 30);
  fill(255);
  text(meusPontos, 150, 40);
  fill(255, 69, 0);
  rect(425, 19, 50, 30);
  fill(255);
  text(pontosDoOponente, 450, 40);
  
}

function marcaPonto(){
  if (xBolinha > 590){
  meusPontos += 1;
    ponto.play();
  }
  if (xBolinha < 10){
  pontosDoOponente += 1;
    ponto.play();
  }
}